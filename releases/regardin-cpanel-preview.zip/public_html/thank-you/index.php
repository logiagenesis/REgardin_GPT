<?php
$page = 'thank-you';
require dirname(__DIR__, 2).'/private/page.php';
